import axios from "axios";
import { createWriteStream, readFileSync } from "fs";
import path from "path";
var mime = require('mime-types');

export class ApiService {
  static url = 'http://api-storage.maciejkubus.usermd.net/api/v1/';
  static fetchQueue: any[] = [];

  static getToken(): string {
    const file = readFileSync('token.json');
    const data = JSON.parse(file.toString());
    const token = data.token;
    return token;
  }

  static async get(path: string) {
    const response = await fetch(`${this.url}${path}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + ApiService.getToken(),
      },
    });
    const json = await response.json();
    return json;
  }

  static async post(path: string, body: any) {
    const response = await fetch(`${this.url}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + ApiService.getToken(),
      },
      body: JSON.stringify(body),
    });
    const json = await response.json();
    return json;
  }

  static async checkIfAlbumExists(albumName: string) {
    const json = await this.get(`albums/mine?filter.title=$eq:${albumName}`);
    const data = json.data;
    return data.length >= 1;
  }

  static async findAlbum(albumName: string) {
    const json = await this.get(`albums/mine?filter.title=$eq:${albumName}`);
    const data = json.data;
    return data[0];
  }

  static async createAlbum(albumName: string) {
    const json = await this.post(`albums`, { title: albumName });
    const data = json.data;
    return data;
  }

  static async checkIfFileIsInAlbum(albumId: string, fileName: string) {
    const json = await this.get(`files/mine?filter.album.id=$eq:${albumId}&filter.originalName=$eq:${fileName}`);
    const data = json.data;
    return data.length >= 1;
  }

  static async uploadFile(filePath: string) {
    const fileData = readFileSync(filePath);
    const fileName = filePath.split("\\").pop();
    const mimeType = mime.lookup(filePath) || "application/octet-stream";
    const fileBlob = new Blob([fileData], { type: mimeType });

    const formData = new FormData();
    formData.append("file", fileBlob, fileName);

    const response = await fetch(`${this.url}files/`, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + ApiService.getToken(),
      },
      body: formData,
    });

    const json = await response.json();
    return json;
  }

  static async addFileToAlbum(albumId: string, fileId: string) {
    const json = await this.post(`albums/${albumId}/add`, { files: [fileId] });
    return json;
  }

  static async getAlbums() {
    const albums: any[] = [];
    let page = 1;
    let total = 1;

    while(page <= total) {
      const json = await this.get(`albums/mine?page=${page}`);
      const data = json.data;
      albums.push(...data);
      page = +json.meta.currentPage + 1;
      total = +json.meta.totalPages;
    }
    return albums;
  }

  static async getFiles(albumId: string) {
    const files: any[] = [];
    let page = 1;
    let total = 1;

    while(page <= total) {
      const json = await this.get(`files/mine?filter.album.id=$eq:${albumId}&page=${page}`);
      const data = json.data;
      files.push(...data);
      page = +json.meta.currentPage + 1;
      total = +json.meta.totalPages;
    }
    return files;
  }

  static async downloadFile(fileId: string, fileName: string, dir: string) {
    const apiUrl = `${this.url}files/${fileId}/download`;
    const filePath = path.join(dir, fileName);
  
    try {
      const response = await axios({
        method: 'GET',
        url: apiUrl,
        headers: {
          'Authorization': 'Bearer ' + ApiService.getToken(),
        },
        responseType: 'stream',
      });
  
      const writer = createWriteStream(filePath);
      response.data.pipe(writer);
  
      return new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });
    } catch (error) {
      throw new Error(`Error downloading file: ${error}`);
    }
  }
}