export const config = {
  token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNzA0OTA5NzE5LCJleHAiOjE3MTI2ODU3MTl9.jtaFboYcjVFqsf8jAr1TCmS2aQ6jaBAKCKbrzzd8p2I'
}