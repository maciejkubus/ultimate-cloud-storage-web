
const elTitle = document.getElementById('title');
const elBtnSelectDir = document.getElementById('btn-select-dir');
const elBtnSync = document.getElementById('btn-sync');
const elBtnLogout = document.getElementById('btn-logout');
const elLogs = document.getElementById('logs');
const loginInput = document.getElementById('login-input');
const passwordInput = document.getElementById('password-input');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const syncScreen = document.getElementById('sync-screen');
const loginScreen = document.getElementById('login-screen');

let title = '';
let token = '';

elBtnSelectDir.addEventListener('click', window.electronAPI.selectDir)

window.electronAPI.onDirSelected( (dir) => {
	elTitle.innerHTML = dir;
	title = dir;
	elBtnSync.removeAttribute('disabled');
	log(`Selected dir: ${dir}`);
});

elBtnSync.addEventListener('click', (event) => {
	event.preventDefault();
	event.stopPropagation();

	if(!title) return;
	window.electronAPI.sync(title);
});

const log = (msg) => {
	if(elLogs.childElementCount > 64) {
		elLogs.removeChild(elLogs.firstChild);
	}
	
	elLogs.innerHTML += `<p class="log">${msg}</p>`;
	elLogs.scrollTop = elLogs.scrollHeight;
}

window.electronAPI.onLog(log);

window.electronAPI.onToken( (data) => {
	if(!data) return;
	token = data;
	syncScreen.classList.remove('hidden');
	loginScreen.classList.add('hidden');
})

loginBtn.addEventListener('click', async () => {
	const login = loginInput.value;
	const password = passwordInput.value;
	const res = await fetch('https://api-storage.maciejkubus.usermd.net/api/v1/auth/login', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({
			username: login,
			password: password,
		})
	})
	if(res.status != 201) {
		loginError.style.display = 'block';
	} else {
		const data = await res.json();
		window.electronAPI.setToken(data.access_token)
		token = data.access_token
		syncScreen.classList.remove('hidden');
		loginScreen.classList.add('hidden');
	}
})

elBtnLogout.addEventListener('click', () => {
	syncScreen.classList.add('hidden');
	loginScreen.classList.remove('hidden');
	token = undefined
	window.electronAPI.setToken(token)
})

setInterval(() => {
	if(token && title) {
		window.electronAPI.sync(title);
	}
}, 60 * 1000)