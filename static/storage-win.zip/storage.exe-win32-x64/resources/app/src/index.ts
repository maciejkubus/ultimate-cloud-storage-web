import { BrowserWindow, Menu, Tray, app, dialog, ipcMain } from 'electron';
import electronReload from 'electron-reload';
import * as fs from 'fs';
import { sync } from './sync';

electronReload(__dirname, {});
let visible = true;

app.whenReady().then(main);

async function main() {
  const window = new BrowserWindow({
    width: 1024,
    height: 600,
    show: false,
    webPreferences: {
      preload: __dirname + '/preload.js',
      devTools: true,
    },
  });

  window.loadFile('./src/public/index.html');
  
  const filesExist = () => {
    if(!fs.existsSync('token.json'))
      fs.writeFileSync('token.json', JSON.stringify({
        token: ""
      }))
    if(!fs.existsSync('path.json'))
      fs.writeFileSync('path.json', JSON.stringify({
        path: ""
      }))
  }

  const getToken = () => {
    const file = fs.readFileSync('token.json');
    const data = JSON.parse(file.toString());
    const token = data.token;
    window.webContents.send('get-token', token);
  }

  const selectDir = () => {
    const file = fs.readFileSync('path.json');
    const data = JSON.parse(file.toString());
    const path = data.path;
    window.webContents.send('selected-dir', path)
  }
  
  window.once('ready-to-show', () => {
    window.show()
    filesExist();
    getToken();
    selectDir();
  });
  window.webContents.openDevTools();

  window.on('minimize', function(event: any){
    event.preventDefault();
    window.hide();
    visible = false;
  });

  let appIcon = null
  app.whenReady().then(() => {
    appIcon = new Tray('./favicon.ico')
    const contextMenu = Menu.buildFromTemplate([
      {
        label: "Show/Hide",
        type: "checkbox",
        click() {
          if (visible) window.hide();
          else window.show();
          visible = !visible;
        }
      },
      {
        label: "Exit",
        click() {
          app.quit();
        }
      }
    ]);

    appIcon.setContextMenu(contextMenu)
  })

  ipcMain.on('set-token', async (event, token) => {
    fs.writeFileSync('token.json', JSON.stringify({
      token
    }))
  })

  ipcMain.on('select-dir', async (event, title) => {
    const webContents = event.sender
    const result = await dialog.showOpenDialog(window, {
      properties: ['openDirectory']
    })
    const path = result.filePaths[0];
    fs.writeFileSync('path.json', JSON.stringify({
      path
    }))
    webContents.send('selected-dir', path)
  })

  ipcMain.on('sync', async (event, path) => {
    const webContents = event.sender
    await sync(path, webContents);
    webContents.send('log', 'Sync completed');
  });

}