import { mkdirSync, readdirSync } from 'fs';
import { ApiService } from './api.service';

const getSubdirs = async (dir: string) => {
  const subdirs = readdirSync(dir, { withFileTypes: true })
    .filter(dirent => dirent.isDirectory())
    .map(dirent => dirent.name)
  
  return subdirs;
}

const processFile = async (file: any, dir: string, subdir: string, album: any, webContents: any) => {
  const exist = await ApiService.checkIfFileIsInAlbum(album.id, file.name);
  if(!exist) {
    const uploadFile = await ApiService.uploadFile(`${dir}\\${subdir}\\${file.name}`);
    await ApiService.addFileToAlbum(album.id, uploadFile.id);
    webContents.send('log', 'Uploaded file: ' + file.name);
  }
};

const syncFiles = async (dir: string, subdir: string, album: any, webContents: any) => {
  const files = readdirSync(`${dir}\\${subdir}`, { withFileTypes: true })
      .filter(dirent => !dirent.isDirectory())

  for (const i in files) {
    const file = files[i];
    await processFile(file, dir, subdir, album, webContents)
  }
}

const processDir = async (dir: string, subdir: string, webContents: any) => {
  const exist = await ApiService.checkIfAlbumExists(subdir);
  
  if(!exist) {
    await ApiService.createAlbum(subdir);
    webContents.send('log', 'Created album: ' + subdir);
  }
  
  const album = await ApiService.findAlbum(subdir);

  await syncFiles(dir, subdir, album, webContents);
};

const uploadAlbums = async (dir: string, webContents: any) => {
  const subdirs = await getSubdirs(dir);
  for (const i in subdirs) {
    const subdir = subdirs[i];
    await processDir(dir, subdir, webContents);
  }
};

const createFolderIfNotPresent = async (dir: string, albumName: string, webContents: any) => {
  const subdirs = await getSubdirs(dir);
  const exist = subdirs.includes(albumName);
  if(!exist) {
    await mkdirSync(`${dir}\\${albumName}`);
    webContents.send('log', 'Created folder: ' + albumName);
  }
}

const checkIfFileIsPresentInDir = async (dir: string, fileName: string) => {
  const files = readdirSync(dir, { withFileTypes: true })
    .filter(dirent => !dirent.isDirectory())
    .map(dirent => dirent.name)

  return files.includes(fileName);
}

const downloadFiles = async (dir: string, subdir: string, album: any, webContents: any) => {
  const files = await ApiService.getFiles(album.id);
  for (const i in files) {
    const file = files[i];
    const exist = await checkIfFileIsPresentInDir(`${dir}\\${subdir}`, file.originalName);
    if(!exist) {
      ApiService.downloadFile(file.id, file.originalName, `${dir}\\${subdir}`);
      webContents.send('log', `Downloaded file: ${subdir}\\${file.originalName}`);
    }
  }
}

const downloadAlbums = async (dir: string, webContents: any) => {
  const albums = await ApiService.getAlbums();
  for (const i in albums) {
    const album = albums[i];
    await createFolderIfNotPresent(dir, album.title, webContents);
    await downloadFiles(dir, album.title, album, webContents);
  }
}

export const sync = async (dir: string, webContents: any) => {
  await uploadAlbums(dir, webContents);
  await downloadAlbums(dir, webContents);
  
}