const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
  selectDir: () => ipcRenderer.send('select-dir'),
  sync: (dir: string) => ipcRenderer.send('sync', dir),
  setToken: (token: string) => ipcRenderer.send('set-token', token),

  onDirSelected: (callback: Function) => ipcRenderer.on('selected-dir', (event, path) => callback(path)),
  onLog: (callback: Function) => ipcRenderer.on('log', (event, message) => callback(message)),
  onToken: (callback: Function) => ipcRenderer.on('get-token', (event, token) => callback(token))
})