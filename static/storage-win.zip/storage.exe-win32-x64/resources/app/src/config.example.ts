export const config = {
  token: 'eyJhbGc...'
}